#!/bin/bash
echo Digo:
read WORD
if [ "$WORD" = "marco" ]; then
    echo 'polo'
else
    echo 'segui participando'
fi
#!/bin/bash
echo Nombre del directorio:
read NAME
mkdir ~/Escritorio/$NAME
echo Directorio creado en el Escritorio